﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vsite.Oom.Battleship.Model;
using Vsite.oom.Battleship.Model;

namespace ShootingStats
{
    class Program
    {
        static void Main(string[] args)
        {
            RulesSingleton rules = RulesSingleton.Instance;
            Shipwright sw = new Shipwright(rules.Rows,rules.Columns);
            Fleet fleet = new Fleet();
            Gunner gunner;
            HitResult result;
            int hitNumber = 0;
            for (int i = 0; i < 10000; i++)
            {
                fleet = sw.CreateFleet(RulesSingleton.Instance.ShipLengths);
                gunner = new Gunner(rules.Rows, rules.Columns, rules.ShipLengths);
                do
                {
                    Square target = new Square(gunner.NextTarget().Rows, gunner.NextTarget().Columns);
                    result = fleet.Hit(target);
                    hitNumber++;
                } while (result != HitResult.Hit);
            }
            Console.WriteLine(hitNumber/10000.0);
            Console.ReadKey();
        }
    }
}
